<?php

return [
    [
        'name' => 'joao',
        'email' => 'joao@yahoo.com'
    ],
    [
        'name' => 'maria',
        'email' => 'maria@gmail.com'
    ],
    [
        'name' => 'julia',
        'email' => 'julia@gmail.com'
    ],
    [
        'name' => 'jaime',
        'email' => 'jaime@hotmail.com'
    ],
    [
        'name' => 'tulio',
        'email' => ''
    ],
];